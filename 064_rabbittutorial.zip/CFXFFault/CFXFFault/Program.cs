﻿using System;
using System.Threading;
using CFX;
using CFX.Structures;
using CFX.ResourcePerformance;
using CFX.Transport;

class Program
{
    static AmqpCFXEndpoint? theEndpoint;
    static string myHandle = "MyCompany.MyMachineModel.12345";
    static string myBroker = "amqp://127.0.0.1:5672";
    static string myExchange = "/exchange/pillarhouse";
    static string myRoutingKey = "cfx";

    static void Main(string[] args)
    {
        OpenEndpoint();

        Console.WriteLine("Endpoint opened and connected.");
        Console.WriteLine("Sending FaultOccurred message repeatedly. Press any key to stop...");

        int count = 0;

        while (!Console.KeyAvailable)
        {
            count++;
            SendFaultOccurred(count);
            Thread.Sleep(5000);
        }

        Console.ReadKey(true);

        CloseEndpoint();
        Console.WriteLine("Endpoint closed. Exiting...");
    }

    static void OpenEndpoint()
    {
        if (theEndpoint != null)
        {
            CloseEndpoint();
        }

        theEndpoint = new AmqpCFXEndpoint();
        theEndpoint.Open(myHandle);
        theEndpoint.AddPublishChannel(new Uri(myBroker), myExchange, myRoutingKey);
    }

    static void SendFaultOccurred(int count)
    {
        var fault = new Fault()
        {
            Cause = FaultCause.MechanicalFailure,
            Severity = FaultSeverity.Error,
            FaultCode = "ERROR 3943480",
            FaultOccurrenceId = Guid.NewGuid(),
            Lane = 1,
            Stage = new Stage()
            {
                StageSequence = 1,
                StageName = "STAGE1",
                StageType = StageType.Work
            },
            SideLocation = SideLocation.Unknown,
            AccessType = AccessType.Unknown,   // <-- แก้ตรงนี้
            Description = "Example fault",
            OccurredAt = DateTime.UtcNow,
            DueDateTime = null
        };

        var faultOccurred = new FaultOccurred()
        {
            Fault = fault
        };

        var env = new CFXEnvelope(faultOccurred);

        theEndpoint?.Publish(env);

        Console.WriteLine($"FaultOccurred message sent #{count}");
    }

    static void CloseEndpoint()
    {
        if (theEndpoint != null)
        {
            theEndpoint.Close();
            theEndpoint = null;
        }
    }
}

﻿using System;
using System.Threading;
using CFX;
using CFX.Structures;
using CFX.ResourcePerformance;
using CFX.Transport;

class Program
{
    static AmqpCFXEndpoint? theEndpoint;
    static string myHandle = "MyCompany.MyMachineModel.Receiver1";
    static string myBroker = "amqp://127.0.0.1:5672";
    static string myQueue = "/queue/cfx";  // subscribe ตรงไปยัง queue cfx ที่มีอยู่แล้ว

    static void Main(string[] args)
    {
        OpenEndpoint();

        Console.WriteLine("Receiver started. Press any key to exit...");

        while (!Console.KeyAvailable)
        {
            Thread.Sleep(100);
        }

        Console.ReadKey(true);

        CloseEndpoint();
        Console.WriteLine("Receiver stopped. Exiting...");
    }

    static void OpenEndpoint()
    {
        if (theEndpoint != null)
        {
            CloseEndpoint();
        }

        theEndpoint = new AmqpCFXEndpoint();
        theEndpoint.Open(myHandle);

        // Subscribe ไปที่ queue cfx ตรงๆ ไม่ต้องใส่ routing key ที่นี่
        theEndpoint.AddSubscribeChannel(new Uri(myBroker), myQueue);

        theEndpoint.OnCFXMessageReceived += TheEndpoint_OnCFXMessageReceived;
    }

    private static void TheEndpoint_OnCFXMessageReceived(object? sender, CFXEnvelope envelope)
    {
        Console.WriteLine("Received envelope:");
        Console.WriteLine($"  MessageName: {envelope.MessageName}");

        if (envelope.MessageBody is LogEntryRecorded log)
        {
            Console.WriteLine($"  Log Message: {log.Message}");
            Console.WriteLine($"  Importance: {log.Importance}");
        }
        else if (envelope.MessageBody is FaultOccurred faultOccurred)
        {
            var fault = faultOccurred.Fault;

            Console.WriteLine("  Fault details:");
            Console.WriteLine($"    Cause: {fault.Cause}");
            Console.WriteLine($"    Severity: {fault.Severity}");
            Console.WriteLine($"    FaultCode: {fault.FaultCode}");
            Console.WriteLine($"    FaultOccurrenceId: {fault.FaultOccurrenceId}");
            Console.WriteLine($"    Lane: {fault.Lane}");
            Console.WriteLine($"    Stage: {(fault.Stage != null ? fault.Stage.StageName : "null")}");
            Console.WriteLine($"    SideLocation: {fault.SideLocation}");
            Console.WriteLine($"    AccessType: {fault.AccessType}");
            Console.WriteLine($"    Description: {fault.Description}");
            Console.WriteLine($"    OccurredAt: {fault.OccurredAt}");
            Console.WriteLine($"    DueDateTime: {fault.DueDateTime}");
        }
        else
        {
            Console.WriteLine("  MessageBody is unknown or unsupported type");
        }
    }

    static void CloseEndpoint()
    {
        if (theEndpoint != null)
        {
            theEndpoint.OnCFXMessageReceived -= TheEndpoint_OnCFXMessageReceived;

            theEndpoint.Close();
            theEndpoint = null;
        }
    }
}

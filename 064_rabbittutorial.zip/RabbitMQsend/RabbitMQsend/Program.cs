﻿using System;
using System.Threading;
using CFX;
using CFX.Structures;
using CFX.ResourcePerformance;
using CFX.Transport;

class Program
{
    static AmqpCFXEndpoint? theEndpoint;
    static string myHandle = "MyCompany.MyMachineModel.12345";
    static string myBroker = "amqp://127.0.0.1:5672";
    static string myExchange = "/exchange/pillarhouse";
    static string myRoutingKey = "cfx";  // Routing key เพื่อให้ message ไปที่ queue cfx

    static void Main(string[] args)
    {
        OpenEndpoint();

        Console.WriteLine("Endpoint opened and connected.");
        Console.WriteLine("Sending 'Running' log entry repeatedly. Press any key to stop...");

        while (!Console.KeyAvailable)
        {
            SendLogEntry();
            Console.WriteLine("Log entry sent: Running");
            Thread.Sleep(5000);
        }

        Console.ReadKey(true);

        CloseEndpoint();
        Console.WriteLine("Endpoint closed. Exiting...");
    }

    static void OpenEndpoint()
    {
        if (theEndpoint != null)
        {
            CloseEndpoint();
        }

        theEndpoint = new AmqpCFXEndpoint();
        theEndpoint.Open(myHandle);

        // เพิ่ม routing key "cfx" ในช่องทางส่ง
        theEndpoint.AddPublishChannel(new Uri(myBroker), myExchange, myRoutingKey);
    }

    static void SendLogEntry()
    {
        var logEntry = new LogEntryRecorded()
        {
            Importance = LogImportance.Debug,
            Message = "Running"
        };

        var env = new CFXEnvelope(logEntry);

        theEndpoint?.Publish(env);
    }

    static void CloseEndpoint()
    {
        if (theEndpoint != null)
        {
            theEndpoint.Close();
            theEndpoint = null;
        }
    }
}

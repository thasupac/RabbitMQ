﻿using System;
using System.Text;
using System.Text.Json;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;

class Receive
{
    public static void Main()
    {
        var factory = new ConnectionFactory() { HostName = "localhost", UserName = "guest", Password = "guest" };
        using var connection = factory.CreateConnection();
        using var channel = connection.CreateModel();

        // ประกาศ exchange แบบ fanout
        channel.ExchangeDeclare("factoryline", ExchangeType.Fanout, durable: false);

        // ประกาศและ bind queue
        channel.QueueDeclare("Receive_para", durable: true, exclusive: false, autoDelete: false);
        channel.QueueBind("Receive_para", "factoryline", routingKey: "");

        var consumer = new EventingBasicConsumer(channel);
        consumer.Received += (model, ea) =>
        {
            var body = ea.Body.ToArray();
            var json = Encoding.UTF8.GetString(body);

            try
            {
                // Deserialize JSON แบบ anonymous
                var message = JsonSerializer.Deserialize<JsonElement>(json);

                Console.WriteLine("📥 Received JSON:");
                Console.WriteLine(message.GetProperty("Message").GetString());
            }
            catch (Exception ex)
            {
                Console.WriteLine("❌ Error decoding JSON: " + ex.Message);
            }
        };

        channel.BasicConsume("Receive_para", autoAck: true, consumer: consumer);
        Console.WriteLine("Waiting for messages. Ctrl+C to exit.");

        while (true) Thread.Sleep(100);
    }
}
